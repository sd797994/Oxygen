﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Oxygen.CommonTool
{
    public class CustomerIp
    {
        public IPEndPoint Ip { get; set; }
    }
}
